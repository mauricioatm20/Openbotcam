rango = range (1,101)
for i in reversed (rango):
    print(f"-{i}")