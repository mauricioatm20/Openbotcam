file = open('mi_primer_archivo.txt', 'w')
file.write('¡hola mundo!\n')
file.close()

file = open('mi_primer_archivo.txt', 'r+')
file.readline()
file.write('hola mundo de nuevo.\n')

file.seek(0)
print(file.read())
file.close()