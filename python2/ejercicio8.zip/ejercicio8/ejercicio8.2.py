#se crea una clase vehiculo, se hace un objeto de ella se guarda y luego se carga

from pickle import *
class Vehiculo:

    def __init__(self, color, modelo):
        self.color = color
        self.modelo = modelo

    def __str__(self):
        return self.color + " " + self.modelo


audi = Vehiculo("blanco", "A3")
print(audi)

file = open('vehiculo_objeto', 'w+b')

dump(audi, file)

file.seek(0)
nuevo_audi = load(file)

print(nuevo_audi)
file.close()