def añobisiesto():
    año: int = int(("2019"))
    if (año % 4== 0 and (año%100 != 0 or año %400==0)):
        print(f"¡ el año {año}es bisiesto!")

    else:
        print(f"lo sentimos . el {año} NO es bisiesto")

print ({añobisiesto()})
