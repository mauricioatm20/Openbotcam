import time

# Inicializamos las variables y formateamos el tiempo para que solo se vean las horas y minutos
hora = time.strftime('%H')
minutos = time.strftime('%M')
segundos = time.strftime('%S')

# Comprobamos si la hora es mayor o igual a 21. Si es mayor, mostrará un mensaje y en el caso de que sea menor mostrará un mensaje informando de las horas y minutos que faltan para ir a casa.
if int(hora) >= 20:
    print ("Es hora de irse a casa")
else:
    print ("Quedan {} horas , {} minutos y {} segundos para irnos a casa".format(19 - int(hora), 59-int(minutos),59-int(segundos)))